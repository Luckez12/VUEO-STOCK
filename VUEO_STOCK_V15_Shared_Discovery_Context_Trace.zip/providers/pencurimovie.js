"use strict";

var PROVIDER_NAME = "PencuriMovie";
var FALLBACK_BASE_URL = "https://ww21.pencurimovie.sbs";
var DOMAIN_CONFIG_URL = "https://raw.githubusercontent.com/Asm0d3usX/CloudX/builds/Website.json";
var TMDB_API_KEY = "1c29a5198ee1854bd5eb45dbe8d17d92";

var USER_AGENT =
  "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/138.0 Mobile Safari/537.36";

var DEFAULT_HEADERS = {
  "User-Agent": USER_AGENT,
  "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
  "Accept-Language": "en-US,en;q=0.9,ms;q=0.8,id;q=0.7"
};

var cachedBaseUrl = null;
var cachedBaseUrlPromise = null;

/* VUEO_SHARED_DISCOVERY_CONTEXT_V1 */
function vueoSharedTmdb(url, fallback) {
  if (
    typeof globalThis !== "undefined" &&
    typeof globalThis.vueoDiscoveryContext === "function"
  ) {
    return globalThis.vueoDiscoveryContext(url)
      .then(function(context) {
        if (context && context.tmdb) {
          if (typeof globalThis.vueoTrace === "function") {
            globalThis.vueoTrace("METADATA", {
              shared: true,
              title: context.title || "",
              year: context.year || "",
              imdbId: context.imdbId || "",
              aliases: Array.isArray(context.aliases) ? context.aliases.length : 0
            });
          }
          return context.tmdb;
        }
        throw new Error("Shared discovery context is empty");
      })
      .catch(function(error) {
        if (typeof globalThis.vueoTrace === "function") {
          globalThis.vueoTrace("METADATA_FALLBACK", {
            reason: error && error.message ? error.message : String(error)
          });
        }
        return fallback();
      });
  }
  return fallback();
}

function vueoCandidateTrace(stage, details) {
  try {
    if (
      typeof globalThis !== "undefined" &&
      typeof globalThis.vueoTrace === "function"
    ) {
      globalThis.vueoTrace(stage, details || {});
    }
  } catch (_) {}
}

function withSoftTimeout(promise, timeoutMs, label) {
  return new Promise(function(resolve, reject) {
    var settled = false;
    var timer = setTimeout(function() {
      if (settled) return;
      settled = true;
      reject(new Error((label || "Request") + " timed out"));
    }, timeoutMs);

    Promise.resolve(promise).then(
      function(value) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(value);
      },
      function(error) {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(error);
      }
    );
  });
}

function requestText(url, headers, timeoutMs) {
  var request = fetch(url, {
    method: "GET",
    headers: Object.assign({}, DEFAULT_HEADERS, headers || {}),
    redirect: "follow"
  }).then(function(response) {
    if (response && response.ok === false) {
      throw new Error("HTTP " + response.status + " for " + url);
    }
    return Promise.resolve(response.text()).then(function(text) {
      return {
        text: String(text || ""),
        url: String(response && response.url || url)
      };
    });
  });

  var requestLabel = "PencuriMovie request";
  try {
    var parsedLabel = new URL(url);
    requestLabel += " " + parsedLabel.hostname + parsedLabel.pathname + parsedLabel.search;
  } catch (_) {}
  return withSoftTimeout(request, timeoutMs || 2200, requestLabel);
}

function requestJson(url, headers, timeoutMs) {
  return requestText(url, headers, timeoutMs).then(function(result) {
    try {
      return JSON.parse(result.text);
    } catch (_) {
      throw new Error("Invalid JSON from " + url);
    }
  });
}

function trimSlash(value) {
  return String(value || "").replace(/\/+$/, "");
}

function safeUrl(value, base) {
  var raw = decodeHtml(String(value || "").trim());
  if (!raw) return "";
  if (raw.indexOf("//") === 0) raw = "https:" + raw;
  try {
    return new URL(raw, base || FALLBACK_BASE_URL).toString();
  } catch (_) {
    return raw;
  }
}

function updateBaseFromUrl(url) {
  try {
    var parsed = new URL(url);
    if (parsed && parsed.origin && parsed.hostname.indexOf("pencurimovie") !== -1) {
      cachedBaseUrl = trimSlash(parsed.origin);
    }
  } catch (_) {}
}

function getBaseUrl() {
  if (cachedBaseUrl) return Promise.resolve(cachedBaseUrl);

  /*
   * Fast path: use the currently verified live domain immediately.
   * Do not make every provider run depend on GitHub Website.json.
   */
  cachedBaseUrl = FALLBACK_BASE_URL;
  return Promise.resolve(cachedBaseUrl);
}

function refreshBaseUrl() {
  if (cachedBaseUrlPromise) return cachedBaseUrlPromise;

  cachedBaseUrlPromise = requestJson(DOMAIN_CONFIG_URL, {}, 900)
    .then(function(data) {
      var values = data && data.pencurimovie;
      var first = Array.isArray(values) ? values[0] : values;
      var resolved = trimSlash(first);
      if (!resolved || resolved.indexOf("http") !== 0) {
        throw new Error("PencuriMovie domain config is empty");
      }
      cachedBaseUrl = resolved;
      return cachedBaseUrl;
    })
    .catch(function() {
      return cachedBaseUrl || FALLBACK_BASE_URL;
    })
    .then(function(value) {
      cachedBaseUrlPromise = null;
      return value;
    });

  return cachedBaseUrlPromise;
}

function decodeHtml(value) {
  return String(value || "")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#x2F;/gi, "/")
    .replace(/&#47;/gi, "/")
    .replace(/&#(\d+);/g, function(_, num) {
      var code = Number(num);
      return isFinite(code) ? String.fromCharCode(code) : _;
    });
}

function stripTags(value) {
  return decodeHtml(String(value || "").replace(/<[^>]*>/g, " "))
    .replace(/\s+/g, " ")
    .trim();
}

function getAttr(tag, name) {
  var pattern = new RegExp(
    "\\b" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") +
    "\\s*=\\s*([\"'])([\\s\\S]*?)\\1",
    "i"
  );
  var match = String(tag || "").match(pattern);
  if (match) return decodeHtml(match[2]);

  pattern = new RegExp(
    "\\b" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") +
    "\\s*=\\s*([^\\s>]+)",
    "i"
  );
  match = String(tag || "").match(pattern);
  return match ? decodeHtml(match[1]) : "";
}

function normalizeTitle(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/\[[^\]]*(?:dub|sub)[^\]]*\]/g, " ")
    .replace(/\b(?:malay\s*dub(?:bed)?|sub\s*indo|indo\s*sub|english\s*sub)\b/g, " ")
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9\u00c0-\uffff]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function titleScore(candidate, expected) {
  var left = normalizeTitle(candidate);
  var right = normalizeTitle(expected);
  if (!left || !right) return 0;
  if (left === right) return 100;
  if (left.indexOf(right) !== -1 || right.indexOf(left) !== -1) return 82;

  var a = left.split(" ").filter(function(word) { return word.length > 1; });
  var b = right.split(" ").filter(function(word) { return word.length > 1; });
  var set = {};
  a.forEach(function(word) { set[word] = true; });

  var matched = b.filter(function(word) { return set[word]; }).length;
  if (!matched) return 0;

  var recall = matched / Math.max(b.length, 1);
  var precision = matched / Math.max(a.length, 1);
  return Math.round((recall * 0.72 + precision * 0.28) * 72);
}


/* VUEO_TITLE_PROFILE_V1 */
function collectTmdbAliases(data, mediaType) {
  var output = [];
  var seen = {};

  function add(value, priority) {
    var text = String(value || "").trim();
    var key = normalizeTitle(text);
    if (!text || !key || seen[key]) return;

    seen[key] = true;
    output.push({
      title: text,
      priority: Number(priority || 0)
    });
  }

  add(data && (data.title || data.name), 100);
  add(
    data &&
    (
      data.original_title ||
      data.original_name
    ),
    95
  );

  var altRoot =
    data &&
    data.alternative_titles;

  var altItems =
    altRoot &&
    (
      Array.isArray(altRoot.titles)
        ? altRoot.titles
        : Array.isArray(altRoot.results)
          ? altRoot.results
          : []
    );

  altItems.forEach(function(item) {
    if (!item) return;

    var country =
      String(
        item.iso_3166_1 || ""
      ).toUpperCase();

    var boost =
      country === "US" ||
      country === "GB"
        ? 86
        : country === "MY" ||
          country === "ID"
          ? 82
          : 72;

    add(
      item.title ||
      item.name,
      boost
    );
  });

  var translations =
    data &&
    data.translations &&
    Array.isArray(
      data.translations.translations
    )
      ? data.translations.translations
      : [];

  translations.forEach(function(item) {
    var row =
      item &&
      item.data &&
      typeof item.data === "object"
        ? item.data
        : {};

    var lang =
      String(
        item &&
        item.iso_639_1 ||
        ""
      ).toLowerCase();

    var boost =
      lang === "en"
        ? 88
        : lang === "ms" ||
          lang === "id"
          ? 80
          : 68;

    add(
      row.title ||
      row.name,
      boost
    );
  });

  output.sort(function(a, b) {
    return b.priority - a.priority;
  });

  return output
    .map(function(item) {
      return item.title;
    })
    .slice(0, 12);
}

function bestAliasTitleScore(candidate, info) {
  var aliases =
    info &&
    Array.isArray(info.aliases) &&
    info.aliases.length
      ? info.aliases
      : [
          info && info.title,
          info && info.originalTitle
        ];

  var best = 0;

  aliases.forEach(function(alias) {
    best = Math.max(
      best,
      titleScore(
        candidate,
        alias
      )
    );
  });

  return best;
}


/* VUEO_DISCOVERY_REBUILD_V1 */
function cleanDiscoveryTitlePencuri(value) {
  return normalizeTitle(
    String(value || "")
      .replace(/\[(?:[^\]]{0,120})\]/g, " ")
      .replace(/\b(?:19|20)\d{2}\b/g, " ")
      .replace(/\bs\d{1,2}(?:\s*[-–]\s*s\d{1,2})?\b/gi, " ")
      .replace(/\b(?:ep|episode|e)\s*[-#:]?\s*\d{1,3}\b/gi, " ")
      .replace(/\b(?:2160p|1080p|720p|480p|4k|web[- ]?dl|bluray|hevc|h26[45]|10bit|malaysub|malaydub|series|movies?)\b/gi, " ")
  );
}

function bestDiscoveryTitleScorePencuri(candidate, info) {
  var aliases =
    info &&
    Array.isArray(info.aliases) &&
    info.aliases.length
      ? info.aliases
      : [
          info && info.title,
          info && info.originalTitle
        ];

  var cleanCandidate =
    cleanDiscoveryTitlePencuri(candidate);

  var best = 0;

  aliases.forEach(function(alias) {
    var cleanAlias =
      cleanDiscoveryTitlePencuri(alias);

    if (!cleanCandidate || !cleanAlias) return;

    if (cleanCandidate === cleanAlias) {
      best = Math.max(best, 100);
    } else if (
      cleanCandidate.indexOf(cleanAlias) !== -1 ||
      cleanAlias.indexOf(cleanCandidate) !== -1
    ) {
      best = Math.max(best, 90);
    } else {
      best = Math.max(
        best,
        titleScore(
          cleanCandidate,
          cleanAlias
        )
      );
    }
  });

  return best;
}

function buildAliasQueries(info, limit) {
  var output = [];
  var seen = {};

  var aliases =
    info &&
    Array.isArray(info.aliases)
      ? info.aliases
      : [
          info && info.title,
          info && info.originalTitle
        ];

  aliases.forEach(function(alias) {
    var text =
      String(alias || "")
        .trim();

    var key =
      normalizeTitle(text);

    if (
      !text ||
      !key ||
      seen[key]
    ) {
      return;
    }

    seen[key] = true;
    output.push(text);
  });

  return output.slice(
    0,
    Math.max(
      1,
      Number(limit || 4)
    )
  );
}

function yearFrom(value) {
  var match = String(value || "").match(/\b(19|20)\d{2}\b/);
  return match ? match[0] : "";
}

function getTmdbInfo(tmdbId, mediaType) {
  var endpoint = mediaType === "movie" ? "movie" : "tv";
  var url =
    "https://api.themoviedb.org/3/" + endpoint + "/" + encodeURIComponent(tmdbId) +
    "?api_key=" + TMDB_API_KEY + "&append_to_response=alternative_titles,translations,external_ids";

  return vueoSharedTmdb(
    url,
    function() {
      return requestJson(url, { "Accept": "application/json" }, 1400);
    }
  ).then(function(data) {
    return {
      tmdbId: String(tmdbId),
      title: String(data && (data.title || data.name) || ""),
      originalTitle: String(data && (data.original_title || data.original_name) || ""),
      year: String(data && (data.release_date || data.first_air_date) || "").split("-")[0],
      aliases: collectTmdbAliases(data, mediaType)
    };
  });
}

function parseSearchResults(html, baseUrl) {
  var results = [];
  var seen = {};
  var rank = 0;

  function add(
    title,
    href,
    year,
    isSeries
  ) {
    var cleanTitle =
      String(title || "")
        .replace(/\s+/g, " ")
        .trim();

    var absolute =
      safeUrl(
        href,
        baseUrl
      );

    if (
      !cleanTitle ||
      !absolute ||
      seen[absolute]
    ) {
      return;
    }

    if (
      /\/(?:category|tag|author|page)\//i.test(absolute)
    ) {
      return;
    }

    seen[absolute] = true;

    results.push({
      title: cleanTitle,
      href: absolute,
      year: year || yearFrom(cleanTitle),
      isSeries:
        Boolean(isSeries) ||
        /\/(?:series|tvshows)\//i.test(absolute),
      rank: rank++
    });
  }

  function addFromBlock(block) {
    var anchorMatch =
      String(block || "")
        .match(
          /<a\b[^>]*href\s*=\s*(["'])[\s\S]*?\1[^>]*>/i
        );

    if (!anchorMatch) return;

    var tag =
      anchorMatch[0];

    var href =
      getAttr(
        tag,
        "href"
      );

    var title =
      getAttr(
        tag,
        "oldtitle"
      ) ||
      getAttr(
        tag,
        "title"
      );

    if (title) {
      title =
        title
          .split("(")[0]
          .trim();
    }

    if (!title) {
      var heading =
        String(block || "")
          .match(
            /<(?:h2|h3)\b[^>]*>([\s\S]*?)<\/(?:h2|h3)>/i
          );

      title =
        heading
          ? stripTags(
              heading[1]
            )
          : "";
    }

    if (!title) {
      var image =
        String(block || "")
          .match(
            /<img\b[^>]*alt\s*=\s*(["'])([\s\S]*?)\1[^>]*>/i
          );

      title =
        image
          ? stripTags(
              image[2]
            )
          : "";
    }

    add(
      title,
      href,
      yearFrom(
        getAttr(
          tag,
          "oldtitle"
        )
      ) ||
        yearFrom(
          block
        ),
      /mli-eps/i.test(block) ||
        /tvseason/i.test(block)
    );
  }

  var cardRegex =
    /<div\b[^>]*class\s*=\s*(["'])[^"']*\bml-item\b[^"']*\1[^>]*>([\s\S]*?)(?=<div\b[^>]*class\s*=\s*(["'])[^"']*\bml-item\b[^"']*\3[^>]*>|$)/gi;

  var card;

  while (
    (card = cardRegex.exec(
      String(html || "")
    ))
  ) {
    addFromBlock(
      card[0]
    );
  }

  /*
   * Generic discovery fallback for site-layout changes.
   */
  var anchorRegex =
    /<a\b[^>]*href\s*=\s*(["'])[\s\S]*?\1[^>]*>([\s\S]*?)<\/a>/gi;

  var anchor;

  while (
    (anchor = anchorRegex.exec(
      String(html || "")
    ))
  ) {
    var tag =
      anchor[0];

    var href =
      getAttr(
        tag,
        "href"
      );

    if (
      !href ||
      !/\/(?:series|tvshows|movies?)\//i.test(href)
    ) {
      continue;
    }

    var title =
      getAttr(
        tag,
        "oldtitle"
      ) ||
      getAttr(
        tag,
        "title"
      ) ||
      stripTags(
        anchor[2]
      );

    add(
      title,
      href,
      yearFrom(title),
      /\/(?:series|tvshows)\//i.test(href)
    );
  }

  return results;
}

function scoreCandidate(item, info, mediaType) {
  var score =
    bestDiscoveryTitleScorePencuri(
      item.title,
      info
    );

  if (
    info.year &&
    item.year &&
    info.year === item.year
  ) {
    score += 18;
  }

  if (
    mediaType === "tv" &&
    item.isSeries
  ) {
    score += 24;
  }

  if (
    mediaType === "movie" &&
    !item.isSeries
  ) {
    score += 18;
  }

  if (
    mediaType === "tv" &&
    !item.isSeries
  ) {
    score -= 40;
  }

  if (
    mediaType === "movie" &&
    item.isSeries
  ) {
    score -= 40;
  }

  score +=
    Math.max(
      0,
      8 -
      Number(
        item.rank ||
        0
      )
    );

  return score;
}

function slugifyTitle(value) {
  var text = String(value || "");

  try {
    if (typeof text.normalize === "function") {
      text = text.normalize("NFKD").replace(/[\u0300-\u036f]/g, "");
    }
  } catch (_) {}

  return text
    .toLowerCase()
    .replace(/&/g, " and ")
    .replace(/[’'`]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .replace(/-+/g, "-");
}

function extractPageIdentity(html) {
  var source = String(html || "");
  var title = "";

  var heading = source.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i);
  if (!heading) heading = source.match(/<h2\b[^>]*>([\s\S]*?)<\/h2>/i);
  if (!heading) heading = source.match(/<h3\b[^>]*>([\s\S]*?)<\/h3>/i);
  if (heading) title = stripTags(heading[1]);

  if (!title) {
    var og = source.match(
      /<meta\b[^>]*property\s*=\s*(["'])og:title\1[^>]*content\s*=\s*(["'])([\s\S]*?)\2[^>]*>/i
    );
    if (og) title = decodeHtml(og[3]);
  }

  var original = source.match(/Original\s+title\s*:\s*([^<\r\n]+)/i);

  return {
    title: String(title || "").replace(/\s*[-|]\s*pencuri.*$/i, "").trim(),
    year: yearFrom(original ? stripTags(original[1]) : title)
  };
}

function isDirectPencuriMatch(result, info, mediaType) {
  if (!result || !result.text) return false;

  var body = String(result.text || "");
  var finalUrl = String(result.url || "");
  var lower = finalUrl.toLowerCase();

  if (
    body.length < 300 ||
    /(?:page not found|404 not found|nothing found)/i.test(body)
  ) {
    return false;
  }

  if (mediaType === "tv" && lower.indexOf("/series/") === -1) return false;
  if (mediaType === "movie" && lower.indexOf("/series/") !== -1) return false;

  var slug = slugifyTitle(info.title);
  var pathSlug = "";
  try {
    var parts = new URL(finalUrl).pathname.split("/").filter(Boolean);
    pathSlug = parts.length ? parts[parts.length - 1] : "";
  } catch (_) {}

  if (slug && pathSlug.indexOf(slug) === 0) return true;

  var identity = extractPageIdentity(body);
  var score =
    bestAliasTitleScore(
      identity.title,
      info
    );

  if (score < 52) return false;
  if (info.year && identity.year && String(info.year) !== String(identity.year)) {
    return false;
  }

  return true;
}

function buildPencuriDirectCandidates(baseUrl, info, mediaType) {
  var titles =
    buildAliasQueries(
      info,
      8
    );

  var output = [];
  var seen = Object.create(null);

  titles.forEach(function(title) {
    var slug = slugifyTitle(title);
    if (!slug) return;

    var paths;
    if (mediaType === "movie") {
      paths = info.year
        ? ["/" + slug + "-" + info.year + "/", "/" + slug + "/"]
        : ["/" + slug + "/"];
    } else {
      paths = info.year
        ? [
            "/series/" + slug + "-" + info.year + "/",
            "/series/" + slug + "/"
          ]
        : ["/series/" + slug + "/"];
    }

    paths.forEach(function(path) {
      var url = trimSlash(cachedBaseUrl || baseUrl) + path;
      if (seen[url]) return;
      seen[url] = true;
      output.push(url);
    });
  });

  return output;
}

function tryDirectPencuriPage(baseUrl, info, mediaType) {
  var candidates = buildPencuriDirectCandidates(baseUrl, info, mediaType);
  if (!candidates.length) return Promise.resolve(null);

  /* VUEO_FAST_DISCOVERY_V1
   * Preserve every direct slug candidate but probe them in a bounded pool.
   * Choose the earliest valid candidate in the original preference order.
   */
  return collectValuesBounded(
    candidates.map(function(url, index) {
      return function() {
        var timeoutMs = index === 0 ? 1400 : 700;
        return requestText(
          url,
          { "Referer": trimSlash(cachedBaseUrl || baseUrl) + "/" },
          timeoutMs
        ).then(function(result) {
          updateBaseFromUrl(result.url || url);
          if (!isDirectPencuriMatch(result, info, mediaType)) return null;
          return {
            index: index,
            match: {
              title: info.title,
              href: result.url || url,
              year: info.year,
              isSeries: mediaType === "tv",
              __detailHtml: result.text
            }
          };
        }).catch(function() { return null; });
      };
    }),
    3,
    3200
  ).then(function(matches) {
    matches = matches.filter(Boolean).sort(function(a, b) {
      return a.index - b.index;
    });
    if (!matches.length) return null;
    console.log("[PencuriMovie] direct permalink hit " + matches[0].match.href);
    return matches[0].match;
  });
}

function searchSite(baseUrl, query) {
  function run(domain) {
    var url = trimSlash(domain) + "/?s=" + encodeURIComponent(query);
    return requestText(url, { "Referer": trimSlash(domain) + "/" }, 1800)
      .then(function(result) {
        updateBaseFromUrl(result.url);
        return parseSearchResults(result.text, result.url);
      });
  }

  return run(baseUrl).catch(function(firstError) {
    return refreshBaseUrl().then(function(refreshed) {
      if (!refreshed || trimSlash(refreshed) === trimSlash(baseUrl)) {
        throw firstError;
      }
      console.log("[PencuriMovie] Retrying with refreshed domain " + refreshed);
      return run(refreshed);
    });
  });
}


function browsePencuriLanding(
  baseUrl,
  mediaType
) {
  var domain =
    trimSlash(
      cachedBaseUrl ||
      baseUrl
    );

  var paths =
    mediaType === "tv"
      ? ["/", "/series/"]
      : ["/", "/movies/"];

  return collectValuesBounded(
    paths.map(function(path) {
      return function() {
        var url =
          domain +
          path;

        return requestText(
          url,
          {
            "Referer":
              domain +
              "/"
          },
          2600
        )
          .then(function(result) {
            updateBaseFromUrl(
              result.url ||
              url
            );

            return parseSearchResults(
              result.text,
              result.url ||
              url
            );
          })
          .catch(function() {
            return [];
          });
      };
    }),
    2,
    4200
  ).then(function(groups) {
    var merged = [];

    groups.forEach(function(group) {
      merged =
        merged.concat(
          Array.isArray(group)
            ? group
            : []
        );
    });

    return merged;
  });
}

function findBestTitle(baseUrl, info, mediaType) {
  return tryDirectPencuriPage(
    baseUrl,
    info,
    mediaType
  ).then(function(direct) {
    if (direct) return direct;

    console.log(
      "[PencuriMovie] direct permalink miss, using discovery search"
    );

    var queries =
      buildAliasQueries(
        info,
        8
      );

    return collectValuesBounded(
      queries.map(function(query) {
        return function() {
          return searchSite(
            cachedBaseUrl ||
            baseUrl,
            query
          )
            .catch(function() {
              return [];
            });
        };
      }),
      3,
      7600
    ).then(function(groups) {
      var seen =
        Object.create(null);

      var candidates = [];

      groups.forEach(function(items) {
        (
          Array.isArray(items)
            ? items
            : []
        ).forEach(function(item) {
          if (
            !item ||
            !item.href ||
            seen[item.href]
          ) {
            return;
          }

          seen[item.href] = true;
          candidates.push(item);
        });
      });

      function choose(items) {
        var list =
          Array.isArray(items)
            ? items.slice()
            : [];

        list.sort(function(a, b) {
          return (
            scoreCandidate(
              b,
              info,
              mediaType
            ) -
            scoreCandidate(
              a,
              info,
              mediaType
            )
          );
        });

        if (!list.length) {
          return null;
        }

        var topScore =
          scoreCandidate(
            list[0],
            info,
            mediaType
          );

        vueoCandidateTrace("CANDIDATE", {
          count: list.length,
          title: list[0] ? list[0].title : "",
          score: topScore
        });

        return topScore >= 44
          ? list[0]
          : null;
      }

      var best =
        choose(candidates);

      if (best) {
        return best;
      }

      return browsePencuriLanding(
        baseUrl,
        mediaType
      ).then(function(landingItems) {
        return choose(
          candidates.concat(
            Array.isArray(landingItems)
              ? landingItems
              : []
          )
        );
      });
    });
  }).then(function(best) {
    if (!best) {
      throw new Error(
        "No PencuriMovie title match"
      );
    }

    if (!best.__detailHtml) {
      var score =
        scoreCandidate(
          best,
          info,
          mediaType
        );

      if (score < 44) {
        throw new Error(
          "PencuriMovie match confidence too low"
        );
      }
    }

    return best;
  });
}

function parseEpisodeTarget(html, pageUrl, requestedSeason, requestedEpisode) {
  var seasonNumber = Number(requestedSeason || 1);
  var episodeNumber = Number(requestedEpisode || 1);
  var matches = [];

  var seasonRegex =
    /<div\b[^>]*class\s*=\s*(["'])[^"']*\btvseason\b[^"']*\1[^>]*>([\s\S]*?)(?=<div\b[^>]*class\s*=\s*(["'])[^"']*\btvseason\b[^"']*\3[^>]*>|$)/gi;

  var seasonBlock;
  while ((seasonBlock = seasonRegex.exec(html))) {
    var block = seasonBlock[0];
    var strong = block.match(/<strong\b[^>]*>([\s\S]*?)<\/strong>/i);
    var blockSeason = strong ? Number((stripTags(strong[1]).match(/season\s*(\d+)/i) || [])[1]) : null;

    var anchorRegex = /<a\b[^>]*href\s*=\s*(["'])[\s\S]*?\1[^>]*>[\s\S]*?<\/a>/gi;
    var anchor;
    while ((anchor = anchorRegex.exec(block))) {
      var tagAndText = anchor[0];
      var tag = (tagAndText.match(/<a\b[^>]*>/i) || [])[0] || "";
      var text = stripTags(tagAndText);
      var epMatch = text.match(/episode\s*(\d+)/i);
      if (!epMatch) continue;

      var href = safeUrl(getAttr(tag, "href"), pageUrl);
      if (!href) continue;

      matches.push({
        season: blockSeason || 1,
        episode: Number(epMatch[1]),
        href: href,
        name: text.replace(/^.*?episode\s*\d+\s*[-:]?\s*/i, "").trim()
      });
    }
  }

  if (!matches.length) {
    var allAnchorRegex = /<a\b[^>]*href\s*=\s*(["'])[\s\S]*?\1[^>]*>[\s\S]*?<\/a>/gi;
    var any;
    while ((any = allAnchorRegex.exec(html))) {
      var item = any[0];
      var itemTag = (item.match(/<a\b[^>]*>/i) || [])[0] || "";
      var itemText = stripTags(item);
      var itemEp = itemText.match(/episode\s*(\d+)/i);
      if (!itemEp) continue;
      var itemHref = safeUrl(getAttr(itemTag, "href"), pageUrl);
      if (!itemHref) continue;
      matches.push({
        season: 1,
        episode: Number(itemEp[1]),
        href: itemHref,
        name: ""
      });
    }
  }

  var exact = matches.find(function(item) {
    return item.season === seasonNumber && item.episode === episodeNumber;
  });

  if (!exact && seasonNumber === 1) {
    exact = matches.find(function(item) {
      return item.episode === episodeNumber;
    });
  }

  if (!exact) {
    throw new Error(
      "PencuriMovie episode S" + seasonNumber + "E" + episodeNumber + " not found"
    );
  }

  return exact;
}


function unescapeScriptText(value) {
  return decodeHtml(String(value || ""))
    .replace(/\\u002f/gi, "/")
    .replace(/\\x2f/gi, "/")
    .replace(/\\\//g, "/")
    .replace(/\\\\/g, "\\");
}

function isDirectMedia(url) {
  return /\.(?:m3u8|mp4)(?:$|[?#])/i.test(String(url || ""));
}

function inferQuality(url, label) {
  var value = (String(label || "") + " " + String(url || "")).toLowerCase();
  if (/\b2160p?\b|\b4k\b/.test(value)) return "2160p";
  if (/\b1440p?\b/.test(value)) return "1440p";
  if (/\b1080p?\b/.test(value)) return "1080p";
  if (/\b720p?\b/.test(value)) return "720p";
  if (/\b480p?\b/.test(value)) return "480p";
  if (/\b360p?\b/.test(value)) return "360p";
  return "Auto";
}

function getHeaderValue(headers, name) {
  try {
    if (headers && typeof headers.get === "function") {
      return headers.get(name) || headers.get(String(name || "").toLowerCase()) || "";
    }
  } catch (_) {}
  return "";
}

function requestRaw(url, options, timeoutMs, label) {
  var supplied = options || {};
  var fetchOptions = {
    method: supplied.method || "GET",
    headers: Object.assign({}, DEFAULT_HEADERS, supplied.headers || {}),
    redirect: supplied.redirect || "follow"
  };

  if (supplied.body !== undefined) fetchOptions.body = supplied.body;

  var request = fetch(url, fetchOptions).then(function(response) {
    var status = Number(response && response.status || 0);
    var manualRedirect = fetchOptions.redirect === "manual" && status >= 300 && status < 400;

    if (!manualRedirect && response && response.ok === false) {
      throw new Error("HTTP " + status + " for " + url);
    }

    return Promise.resolve(response.text()).then(function(text) {
      return {
        text: String(text || ""),
        url: String(response && response.url || url),
        status: status,
        headers: response && response.headers
      };
    });
  });

  return withSoftTimeout(
    request,
    timeoutMs || 2200,
    label || "PencuriMovie extractor request"
  );
}

function requestPostForm(url, data, headers, timeoutMs) {
  var body = Object.keys(data || {}).map(function(key) {
    return encodeURIComponent(key) + "=" + encodeURIComponent(String(data[key] == null ? "" : data[key]));
  }).join("&");

  return requestRaw(url, {
    method: "POST",
    headers: Object.assign({
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
    }, headers || {}),
    body: body,
    redirect: "follow"
  }, timeoutMs || 2200, "PencuriMovie POST " + url);
}

function extractDirectMedia(text, baseUrl) {
  var source = unescapeScriptText(text);
  var found = [];
  var seen = {};

  function add(value, label) {
    var url = safeUrl(value, baseUrl);
    if (!url || !isDirectMedia(url) || seen[url]) return;
    seen[url] = true;
    found.push({
      url: url,
      quality: inferQuality(url, label)
    });
  }

  var absoluteRegex = /https?:\/\/[^"'<>\\\s]+?\.(?:m3u8|mp4)(?:\?[^"'<>\\\s]*)?/gi;
  var absolute;
  while ((absolute = absoluteRegex.exec(source))) add(absolute[0], "");

  var keyedRegex =
    /(?:file|src|source|url)\s*[:=]\s*(["'])([^"']+\.(?:m3u8|mp4)(?:\?[^"']*)?)\1/gi;
  var keyed;
  while ((keyed = keyedRegex.exec(source))) add(keyed[2], keyed[0]);

  var sourceTagRegex = /<source\b[^>]*>/gi;
  var sourceTag;
  while ((sourceTag = sourceTagRegex.exec(source))) {
    add(getAttr(sourceTag[0], "src"), sourceTag[0]);
  }

  return found;
}

function extractJwPlayerMedia(text, baseUrl) {
  var source = unpackPackedScripts(unescapeScriptText(text));
  var found = extractDirectMedia(source, baseUrl);
  var seen = {};
  found.forEach(function(item) { seen[item.url] = true; });

  function add(raw, label, type) {
    var url = safeUrl(raw, baseUrl);
    if (!url || seen[url]) return;

    var lower = String(url).toLowerCase();
    var typeLower = String(type || "").toLowerCase();

    var looksPlayable =
      isDirectMedia(url) ||
      /\.txt(?:$|[?#])/i.test(url) ||
      typeLower.indexOf("mpegurl") !== -1 ||
      typeLower.indexOf("m3u8") !== -1 ||
      typeLower.indexOf("mp4") !== -1 ||
      typeLower.indexOf("video") !== -1;

    if (!looksPlayable) return;
    seen[url] = true;
    found.push({
      url: url,
      quality: inferQuality(url, label)
    });
  }

  var objectRegex = /\{[\s\S]{0,600}?\}/g;
  var objectMatch;
  while ((objectMatch = objectRegex.exec(source))) {
    var block = objectMatch[0];
    var file = block.match(/\b(?:file|src)\s*:\s*(["'])(.*?)\1/i);
    if (!file) continue;
    var label = (block.match(/\b(?:label|quality)\s*:\s*(["'])(.*?)\1/i) || [])[2] || "";
    var type = (block.match(/\btype\s*:\s*(["'])(.*?)\1/i) || [])[2] || "";
    add(file[2], label, type);
  }

  var bareFileRegex = /\b(?:file|src)\s*:\s*(["'])(https?:\/\/[^"']+)\1/gi;
  var bare;
  while ((bare = bareFileRegex.exec(source))) add(bare[2], "", "");

  return found;
}

function extractSubtitles(text, baseUrl) {
  var source = unpackPackedScripts(unescapeScriptText(text));
  var output = [];
  var seen = {};

  function add(url, label) {
    var absolute = safeUrl(url, baseUrl);
    if (!absolute || seen[absolute]) return;
    if (!/\.(?:vtt|srt)(?:$|[?#])/i.test(absolute)) return;

    seen[absolute] = true;
    var lower = String(label || "").toLowerCase();
    var lang = lower.indexOf("malay") !== -1 || /\bms\b/.test(lower) ? "ms" :
      lower.indexOf("indones") !== -1 || /\bid\b/.test(lower) ? "id" :
      lower.indexOf("english") !== -1 || /\ben\b/.test(lower) ? "en" : "und";

    output.push({
      label: label || (lang === "und" ? "Subtitle" : lang.toUpperCase()),
      language: label || lang,
      lang: lang,
      url: absolute,
      default: false,
      format: /\.srt(?:$|[?#])/i.test(absolute) ? "srt" : "vtt"
    });
  }

  var trackRegex = /<track\b[^>]*>/gi;
  var track;
  while ((track = trackRegex.exec(source))) {
    add(
      getAttr(track[0], "src"),
      getAttr(track[0], "label") || getAttr(track[0], "srclang")
    );
  }

  var objectRegex = /\{[\s\S]{0,500}?\}/g;
  var objectMatch;
  while ((objectMatch = objectRegex.exec(source))) {
    var block = objectMatch[0];
    var file = block.match(/\b(?:file|src)\s*:\s*(["'])(.*?\.(?:vtt|srt)(?:\?[^"']*)?)\1/i);
    if (!file) continue;
    var label = (block.match(/\b(?:label|srclang|language)\s*:\s*(["'])(.*?)\1/i) || [])[2] || "";
    add(file[2], label);
  }

  var rawRegex = /https?:\/\/[^"'<>\\\s]+?\.(?:vtt|srt)(?:\?[^"'<>\\\s]*)?/gi;
  var raw;
  while ((raw = rawRegex.exec(source))) add(raw[0], "Subtitle");

  return output;
}

function extractIframes(text, baseUrl) {
  var source = unescapeScriptText(text);
  var output = [];
  var seen = {};
  var regex = /<iframe\b[^>]*>/gi;
  var match;

  while ((match = regex.exec(source))) {
    var tag = match[0];
    var raw =
      getAttr(tag, "data-src") ||
      getAttr(tag, "data-lazy-src") ||
      getAttr(tag, "src");

    var url = safeUrl(raw, baseUrl);
    if (!url || seen[url]) continue;

    var lower = url.toLowerCase();
    if (
      lower.indexOf("youtube.com") !== -1 ||
      lower.indexOf("youtu.be") !== -1 ||
      lower.indexOf("youtube-nocookie.com") !== -1 ||
      lower.indexOf("about:blank") === 0
    ) {
      continue;
    }

    seen[url] = true;
    output.push(url);
  }

  return output;
}

/*
 * Jsoup's "div.movieplay iframe" selector handles nested divs. A regex that
 * stops on the first </div> does not. This balanced scan mirrors the DOM
 * selector closely enough for the PencuriMovie server tabs.
 */
function extractMovieplayIframes(text, baseUrl) {
  var source = unescapeScriptText(text);
  var output = [];
  var seen = {};
  var openRegex = /<div\b[^>]*>/gi;
  var open;

  while ((open = openRegex.exec(source))) {
    var openTag = open[0];
    var className = getAttr(openTag, "class");
    if (!/(^|\s)movieplay(\s|$)/i.test(className)) continue;

    var blockStart = open.index;
    var scanStart = openRegex.lastIndex;
    var tokenRegex = /<div\b[^>]*>|<\/div\s*>/gi;
    tokenRegex.lastIndex = scanStart;

    var depth = 1;
    var endIndex = source.length;
    var token;
    while ((token = tokenRegex.exec(source))) {
      if (/^<div\b/i.test(token[0])) depth += 1;
      else depth -= 1;

      if (depth === 0) {
        endIndex = tokenRegex.lastIndex;
        break;
      }
    }

    var block = source.slice(blockStart, endIndex);
    extractIframes(block, baseUrl).forEach(function(url) {
      if (seen[url]) return;
      seen[url] = true;
      output.push(url);
    });

    openRegex.lastIndex = endIndex;
  }

  return output;
}

function extractRedirectTarget(text, baseUrl) {
  var source = unescapeScriptText(text);

  var meta = source.match(
    /<meta\b[^>]*http-equiv\s*=\s*(["'])?refresh\1?[^>]*content\s*=\s*(["'])([\s\S]*?)\2[^>]*>/i
  );
  if (meta) {
    var target = meta[3].match(/url\s*=\s*(.+)$/i);
    if (target) return safeUrl(target[1].replace(/^["']|["']$/g, ""), baseUrl);
  }

  var locationMatch = source.match(
    /(?:window\.)?location(?:\.href)?\s*=\s*(["'])(https?:\/\/[^"']+)\1/i
  );
  return locationMatch ? safeUrl(locationMatch[2], baseUrl) : "";
}

function followRedirectCloudstream(url, referer) {
  var absolute = safeUrl(url, referer);
  if (!absolute) return Promise.resolve("");

  return requestRaw(absolute, {
    method: "GET",
    headers: referer ? { "Referer": referer } : {},
    redirect: "manual"
  }, 1400, "PencuriMovie redirect " + absolute).then(function(result) {
    var location = getHeaderValue(result.headers, "location");
    if (location) return safeUrl(location, absolute);

    var meta = extractRedirectTarget(result.text, absolute);
    if (meta) return meta;

    /*
     * Some fetch implementations ignore redirect:"manual". In that case
     * response.url is already the final URL, which is still useful.
     */
    return result.url || absolute;
  }).catch(function() {
    return absolute;
  });
}

function mergeResolved(target, source) {
  var streamSeen = {};
  target.streams.forEach(function(item) { streamSeen[item.url] = true; });
  (source.streams || []).forEach(function(item) {
    if (!item || !item.url || streamSeen[item.url]) return;
    streamSeen[item.url] = true;
    target.streams.push(item);
  });

  var subtitleSeen = {};
  target.subtitles.forEach(function(item) { subtitleSeen[item.url] = true; });
  (source.subtitles || []).forEach(function(item) {
    if (!item || !item.url || subtitleSeen[item.url]) return;
    subtitleSeen[item.url] = true;
    target.subtitles.push(item);
  });

  return target;
}

function emptyResolved() {
  return { streams: [], subtitles: [] };
}

function resolvedFromText(text, pageUrl, headers) {
  return {
    streams: extractJwPlayerMedia(text, pageUrl).map(function(item) {
      return {
        url: item.url,
        quality: item.quality,
        referer: pageUrl,
        headers: headers || {}
      };
    }),
    subtitles: extractSubtitles(text, pageUrl)
  };
}

function extractScriptBodies(text) {
  var source = String(text || "");
  var scripts = [];
  var regex = /<script\b[^>]*>([\s\S]*?)<\/script>/gi;
  var match;
  while ((match = regex.exec(source))) scripts.push(match[1]);
  return scripts;
}

/*
 * Cloudstream uses JsUnpacker/getAndUnpack for Dean Edwards P.A.C.K.E.R.
 * We intercept the packer's eval so the decoded source is returned instead
 * of executing the decoded player code.
 */
function unpackPackedScripts(text) {
  var source = String(text || "");
  var additions = [];

  extractScriptBodies(source).forEach(function(body) {
    if (body.indexOf("eval(function(p,a,c,k,e") === -1) return;

    try {
      var candidate = body.trim().replace(/;\s*$/, "");
      var factory = Function(
        "safeEval",
        "return (function(eval){ return (" + candidate + "); })(safeEval);"
      );
      var decoded = factory(function(code) { return String(code || ""); });
      if (decoded && typeof decoded === "string") additions.push(decoded);
    } catch (_) {}
  });

  return additions.length ? source + "\n" + additions.join("\n") : source;
}

function originOf(url) {
  try {
    return new URL(url).origin;
  } catch (_) {
    return "";
  }
}

function hostOf(url) {
  try {
    return String(new URL(url).hostname || "").toLowerCase();
  } catch (_) {
    return "";
  }
}

function hostMatches(host, domains) {
  var value = String(host || "").toLowerCase();
  return (domains || []).some(function(domain) {
    var d = String(domain || "").toLowerCase();
    return value === d || value.slice(-(d.length + 1)) === "." + d;
  });
}

var STREAMWISH_DOMAINS = [
  "streamwish.to", "mwish.pro", "dwish.pro", "embedwish.com", "hgcloud.to",
  "wishembed.pro", "kswplayer.info", "wishfast.top", "streamwish.site",
  "sfastwish.com", "strwish.xyz", "strwish.com", "flaswish.com", "awish.pro",
  "obeywish.com", "jodwish.com", "swhoi.com", "multimovies.cloud",
  "uqloads.xyz", "doodporn.xyz", "cdnwish.com", "asnwish.com",
  "nekowish.my.id", "neko-stream.click", "swdyu.com", "wishonly.site",
  "playerwish.com", "streamhls.to", "hlswish.com", "hglink.to"
];

var VIDHIDE_DOMAINS = [
  "vidhidepro.com", "vidhidehub.com", "vidhidevip.com", "vidhidepre.com",
  "smoothpre.com", "dhtpre.com", "peytonepre.com", "filelions.live",
  "filelions.online", "filelions.to", "kinoger.be", "vidhide.com",
  "rubyvidhub.com", "server2.shop"
];

var FILEMOON_DOMAINS = ["filemoon.to", "filemoon.in", "filemoon.sx"];
var STREAMTAPE_DOMAINS = [
  "streamtape.com", "streamtape.net", "streamtape.xyz",
  "watchadsontape.com", "shavetape.cash"
];
var DOOD_DOMAINS = [
  "dood.la", "dood.pm", "dood.to", "dood.so", "dood.ws", "dood.yt",
  "dood.li", "dood.watch", "dood.cx", "dood.sh", "dood.wf",
  "ds2play.com", "ds2video.com", "vide0.net", "myvidplay.com", "playmogo.com"
];
var MIXDROP_DOMAINS = [
  "mixdrop.co", "mixdrop.bz", "mixdrop.ch", "mixdrop.to",
  "mixdrop.si", "mixdrop.ps", "mixdrop.ag"
];
var VIDMOLY_DOMAINS = ["vidmoly.net", "vidmoly.me", "vidmoly.to", "vidmoly.biz"];
var LULU_DOMAINS = ["luluvdo.com", "luluvdoo.com", "lulustream.com", "kinoger.pw"];
var VOE_DOMAINS = [
  "voe.sx", "donaldlineelse.com", "charlestoughrace.com", "yip.su",
  "metagnathtuggers.com", "tubelessceliolymph.com", "simpulumlamerop.com",
  "urochsunloath.com", "nathanfromsubject.com"
];

function extractStreamWish(url, referer) {
  var origin = originOf(url);
  var resolvedUrl = url;

  try {
    var parsed = new URL(url);
    var match = parsed.pathname.match(/\/(?:f|e)\/([^/?#]+)/i);
    if (match) resolvedUrl = origin + "/" + match[1];
  } catch (_) {}

  var headers = {
    "Accept": "*/*",
    "Connection": "keep-alive",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site",
    "Referer": origin + "/",
    "Origin": origin,
    "User-Agent": USER_AGENT
  };

  return requestRaw(resolvedUrl, {
    headers: Object.assign({}, headers, referer ? { "Referer": referer } : {}),
    redirect: "follow"
  }, 2500, "StreamWish " + resolvedUrl).then(function(result) {
    return resolvedFromText(result.text, result.url || resolvedUrl, headers);
  });
}

function extractVidHide(url, referer) {
  var embed = String(url || "")
    .replace("/d/", "/v/")
    .replace("/download/", "/v/")
    .replace("/file/", "/v/")
    .replace("/f/", "/v/");

  var origin = originOf(embed);
  var headers = {
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site",
    "Origin": origin,
    "User-Agent": USER_AGENT
  };
  if (referer) headers["Referer"] = referer;

  return requestRaw(embed, {
    headers: headers,
    redirect: "follow"
  }, 2500, "VidHide " + embed).then(function(result) {
    return resolvedFromText(result.text, result.url || embed, headers);
  });
}

function extractFileMoon(url, referer) {
  var defaultHeaders = {
    "Referer": url,
    "Sec-Fetch-Dest": "iframe",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "cross-site",
    "User-Agent": USER_AGENT
  };
  if (referer) defaultHeaders["Referer"] = referer;

  return requestRaw(url, {
    headers: defaultHeaders,
    redirect: "follow"
  }, 2400, "FileMoon " + url).then(function(initial) {
    var frames = extractIframes(initial.text, initial.url || url);

    if (!frames.length) {
      return resolvedFromText(initial.text, initial.url || url, defaultHeaders);
    }

    return requestRaw(frames[0], {
      headers: Object.assign({}, defaultHeaders, {
        "Accept-Language": "en-US,en;q=0.5",
        "Referer": initial.url || url
      }),
      redirect: "follow"
    }, 2400, "FileMoon iframe " + frames[0]).then(function(frame) {
      return resolvedFromText(frame.text, frame.url || frames[0], defaultHeaders);
    });
  });
}

function randomToken(length) {
  var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  var output = "";
  for (var i = 0; i < length; i++) {
    output += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
  }
  return output;
}

function extractDood(url) {
  var embedUrl = String(url || "").replace("/d/", "/e/");

  return requestRaw(embedUrl, {
    redirect: "follow"
  }, 2200, "Dood " + embedUrl).then(function(page) {
    var base = originOf(page.url || embedUrl);
    var md5Match = page.text.match(/\/pass_md5\/[^'"\s<]+/i);
    if (!md5Match) return emptyResolved();

    var md5Url = base + md5Match[0];
    return requestRaw(md5Url, {
      headers: { "Referer": page.url || embedUrl },
      redirect: "follow"
    }, 1800, "Dood pass_md5").then(function(md5) {
      var token = "";
      try {
        token = new URL(md5Url).pathname.split("/").filter(Boolean).pop() || "";
      } catch (_) {}

      var trueUrl = String(md5.text || "").trim() + randomToken(10) + "?token=" + token;
      if (!/^https?:\/\//i.test(trueUrl)) return emptyResolved();

      return {
        streams: [{
          url: trueUrl,
          quality: inferQuality(page.text, ""),
          referer: base + "/",
          headers: { "Referer": base + "/" }
        }],
        subtitles: []
      };
    });
  });
}

function extractMixDrop(url) {
  var embed = String(url || "").replace("/f/", "/e/");

  return requestRaw(embed, {
    redirect: "follow"
  }, 2300, "MixDrop " + embed).then(function(result) {
    var unpacked = unpackPackedScripts(result.text);
    var match = unpacked.match(/wurl.*?=.*?(["'])(.*?)\1\s*;/i);

    if (match && match[2]) {
      var direct = safeUrl(match[2], result.url || embed);
      return {
        streams: [{
          url: direct,
          quality: inferQuality(direct, ""),
          referer: url,
          headers: { "Referer": url }
        }],
        subtitles: extractSubtitles(unpacked, result.url || embed)
      };
    }

    return resolvedFromText(unpacked, result.url || embed, { "Referer": url });
  });
}

function extractVidmoly(url, referer) {
  var embed = String(url || "");
  if (embed.indexOf("/w/") !== -1) {
    embed = embed.replace("/w/", "/embed-") + ".html";
  }

  var headers = {
    "User-Agent": USER_AGENT,
    "Sec-Fetch-Dest": "iframe"
  };
  if (referer) headers["Referer"] = referer;

  return requestRaw(embed, {
    headers: headers,
    redirect: "follow"
  }, 2300, "Vidmoly " + embed).then(function(result) {
    return resolvedFromText(result.text, result.url || embed, headers);
  });
}

function extractLulu(url, referer) {
  var parsed;
  try {
    parsed = new URL(url);
  } catch (_) {
    return Promise.resolve(emptyResolved());
  }

  var segments = parsed.pathname.split("/").filter(Boolean);
  var filecode = segments.length ? segments[segments.length - 1] : "";
  if (!filecode) return Promise.resolve(emptyResolved());

  var postUrl = parsed.origin + "/dl";
  return requestPostForm(postUrl, {
    op: "embed",
    file_code: filecode,
    auto: "1",
    referer: referer || ""
  }, referer ? { "Referer": referer } : {}, 2300).then(function(result) {
    return resolvedFromText(result.text, result.url || postUrl, {
      "Referer": referer || parsed.origin + "/"
    });
  });
}

function evalStringExpression(expression) {
  var expr = String(expression || "").trim().replace(/;\s*$/, "");
  if (!expr) return "";

  /*
   * StreamTape's Cloudstream extractor evaluates the small RHS expression used
   * to build the botlink. This equivalent evaluates only that extracted RHS.
   */
  try {
    return String(Function("return (" + expr + ");")() || "");
  } catch (_) {
    var protocolRelative = expr.match(/(["'])(\/\/[^"']+)\1/);
    return protocolRelative ? protocolRelative[2] : "";
  }
}

function extractStreamTape(url) {
  return requestRaw(url, {
    redirect: "follow"
  }, 2300, "StreamTape " + url).then(function(result) {
    var lines = String(result.text || "").split(/\r?\n/);
    var line = lines.find(function(value) {
      return value.indexOf("botlink').innerHTML") !== -1 ||
        value.indexOf('botlink").innerHTML') !== -1;
    });

    if (!line) return emptyResolved();

    var marker = line.indexOf(").innerHTML");
    if (marker === -1) return emptyResolved();

    var rhs = line.slice(marker + ").innerHTML".length).replace(/^\s*=\s*/, "");
    var value = evalStringExpression(rhs);
    if (!value) return emptyResolved();

    var direct = value.indexOf("//") === 0 ? "https:" + value : safeUrl(value, result.url || url);
    if (direct.indexOf("stream=1") === -1) {
      direct += (direct.indexOf("?") === -1 ? "?" : "&") + "stream=1";
    }

    return {
      streams: [{
        url: direct,
        quality: "Auto",
        referer: url,
        headers: { "Referer": url }
      }],
      subtitles: []
    };
  });
}

function base64DecodeText(value) {
  var input = String(value || "").replace(/\s+/g, "");

  try {
    if (typeof atob === "function") return atob(input);
  } catch (_) {}

  try {
    if (typeof Buffer !== "undefined") {
      return Buffer.from(input, "base64").toString("binary");
    }
  } catch (_) {}

  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
  var output = "";
  var i = 0;

  while (i < input.length) {
    var enc1 = chars.indexOf(input.charAt(i++));
    var enc2 = chars.indexOf(input.charAt(i++));
    var enc3 = chars.indexOf(input.charAt(i++));
    var enc4 = chars.indexOf(input.charAt(i++));

    var chr1 = (enc1 << 2) | (enc2 >> 4);
    var chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
    var chr3 = ((enc3 & 3) << 6) | enc4;

    output += String.fromCharCode(chr1);
    if (enc3 !== 64 && enc3 !== -1) output += String.fromCharCode(chr2);
    if (enc4 !== 64 && enc4 !== -1) output += String.fromCharCode(chr3);
  }

  return output;
}

function rot13(value) {
  return String(value || "").replace(/[A-Za-z]/g, function(char) {
    var code = char.charCodeAt(0);
    var base = code >= 97 ? 97 : 65;
    return String.fromCharCode(((code - base + 13) % 26) + base);
  });
}

function decryptVoeF7(encoded) {
  try {
    var value = rot13(encoded);
    ["@$", "^^", "~@", "%?", "*~", "!!", "#&"].forEach(function(pattern) {
      value = value.split(pattern).join("_");
    });
    value = value.replace(/_/g, "");

    var stage1 = base64DecodeText(value);
    var shifted = "";
    for (var i = 0; i < stage1.length; i++) {
      shifted += String.fromCharCode(stage1.charCodeAt(i) - 3);
    }

    var reversed = shifted.split("").reverse().join("");
    return JSON.parse(base64DecodeText(reversed));
  } catch (_) {
    return null;
  }
}

function extractVoe(url, referer) {
  function read(pageUrl) {
    return requestRaw(pageUrl, {
      headers: referer ? { "Referer": referer } : {},
      redirect: "follow"
    }, 2300, "Voe " + pageUrl);
  }

  return read(url).then(function(first) {
    var redirect = String(first.text || "").match(
      /window\.location\.href\s*=\s*'([^']+)'\s*;?/i
    );

    var pagePromise = redirect && redirect[1]
      ? read(safeUrl(redirect[1], first.url || url))
      : Promise.resolve(first);

    return pagePromise.then(function(page) {
      var script = String(page.text || "").match(
        /<script\b[^>]*type\s*=\s*(["'])application\/json\1[^>]*>([\s\S]*?)<\/script>/i
      );
      if (!script) return emptyResolved();

      var raw = String(script[2] || "").trim();
      var encoded = "";

      try {
        var parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length) encoded = String(parsed[0] || "");
      } catch (_) {}

      if (!encoded) {
        var encodedMatch = raw.match(/^\s*\[\s*"([\s\S]*?)"\s*\]\s*$/);
        if (encodedMatch) encoded = encodedMatch[1];
      }

      var decrypted = decryptVoeF7(encoded);
      if (!decrypted) return emptyResolved();

      var streams = [];
      var origin = originOf(page.url || url);

      if (decrypted.source) {
        streams.push({
          url: safeUrl(decrypted.source, page.url || url),
          quality: inferQuality(decrypted.source, ""),
          referer: origin + "/",
          headers: { "Origin": origin, "Referer": origin + "/" }
        });
      }

      if (decrypted.direct_access_url) {
        streams.push({
          url: safeUrl(decrypted.direct_access_url, page.url || url),
          quality: inferQuality(decrypted.direct_access_url, ""),
          referer: url,
          headers: { "Referer": url }
        });
      }

      return { streams: streams, subtitles: [] };
    });
  });
}

function extractGenericHost(url, referer, depth, allowWebView) {
  return requestRaw(url, {
    headers: referer ? { "Referer": referer } : {},
    redirect: "follow"
  }, 2300, "Generic extractor " + url).then(function(result) {
    var resolved = resolvedFromText(
      result.text,
      result.url || url,
      referer ? { "Referer": referer } : {}
    );

    if (resolved.streams.length || Number(depth || 0) >= 1) return resolved;

    var nested = extractIframes(result.text, result.url || url).slice(0, 2);
    if (!nested.length) return resolved;

    return collectResolvedBounded(
      nested.map(function(child) {
        return function() {
          return loadExtractorEquivalent(
            child,
            result.url || url,
            Number(depth || 0) + 1,
            allowWebView
          ).catch(function() {
            return emptyResolved();
          });
        };
      }),
      2,
      1900
    ).then(function(children) {
      mergeResolved(
        resolved,
        children
      );
      return resolved;
    });
  });
}


function collectValuesBounded(
  factories,
  concurrency,
  timeoutMs
) {
  var jobs =
    Array.isArray(factories)
      ? factories
      : [];

  if (!jobs.length) {
    return Promise.resolve([]);
  }

  var limit =
    Math.max(
      1,
      Number(concurrency || 1)
    );

  return new Promise(function(resolve) {
    var output = [];
    var next = 0;
    var active = 0;
    var done = false;

    var timer =
      setTimeout(
        finish,
        Math.max(
          1,
          Number(timeoutMs || 1)
        )
      );

    function finish() {
      if (done) return;
      done = true;
      clearTimeout(timer);
      resolve(output);
    }

    function pump() {
      if (done) return;

      if (
        next >= jobs.length &&
        active === 0
      ) {
        finish();
        return;
      }

      while (
        !done &&
        active < limit &&
        next < jobs.length
      ) {
        var factory =
          jobs[next++];

        active += 1;

        Promise.resolve()
          .then(factory)
          .then(function(value) {
            if (
              !done &&
              value !== undefined &&
              value !== null
            ) {
              output.push(value);
            }
          })
          .catch(function() {})
          .then(function() {
            active -= 1;
            pump();
          });
      }
    }

    pump();
  });
}

function collectResolvedBounded(
  factories,
  concurrency,
  timeoutMs
) {
  return collectValuesBounded(
    factories,
    concurrency,
    timeoutMs
  ).then(function(results) {
    var merged =
      emptyResolved();

    results.forEach(function(result) {
      mergeResolved(
        merged,
        result || emptyResolved()
      );
    });

    return merged;
  });
}

function nativeWebViewAvailable() {
  return (
    typeof globalThis !== "undefined" &&
    typeof globalThis.webviewResolve === "function"
  );
}


function sanitizeNativePlaybackHeaders(rawHeaders, mirrorUrl) {
  var blocked = {
    "host": true,
    "connection": true,
    "accept-encoding": true,
    "range": true,
    "origin": true
  };

  var headers = {};
  var input =
    rawHeaders && typeof rawHeaders === "object"
      ? rawHeaders
      : {};

  Object.keys(input).forEach(function(key) {
    var lower = String(key).toLowerCase();
    if (blocked[lower]) return;
    headers[String(key)] = String(input[key]);
  });

  headers["User-Agent"] =
    headers["User-Agent"] ||
    headers["user-agent"] ||
    USER_AGENT;
  headers["Accept"] =
    headers["Accept"] ||
    headers["accept"] ||
    "*/*";

  /*
   * Cloudstream sets ExtractorLink.referer to the player mirror URL even when
   * the intercepted WebView request carried another transient Referer.
   */
  delete headers["referer"];
  headers["Referer"] = mirrorUrl;

  return headers;
}

function nativeTransportScore(url) {
  var value = String(url || "").toLowerCase();
  if (value.indexOf(".m3u8") !== -1) return 30;
  if (value.indexOf(".mp4") !== -1) return 20;
  if (value.indexOf(".m4v") !== -1) return 20;
  if (value.indexOf("/sora/") !== -1) return 10;
  return 0;
}

function resolveWithNativeWebView(url, referer, label) {
  if (!nativeWebViewAvailable()) {
    return Promise.resolve(emptyResolved());
  }

  var absolute = safeUrl(url, referer);
  if (!absolute) return Promise.resolve(emptyResolved());

  console.log(
    "[" + PROVIDER_NAME + "] native WebView start host=" + hostOf(absolute)
  );

  return globalThis.webviewResolve(absolute, {
    referer: referer || absolute,
    timeoutMs: 6500,
    finishAfterFirstMs: 600,
    clickDelaysMs: [
      650,
      1300,
      2200,
      3400,
      5000,
      6200
    ],
    match: [
      "/sora/",
      ".m3u8",
      ".mp4",
      ".m4v"
    ],
    blocked: [
      "doubleclick",
      "googlesyndication",
      "/ads/",
      "vast"
    ],
    injectAbyssHook: true
  }).then(function(result) {
    var nativeStreams =
      result && Array.isArray(result.streams)
        ? result.streams
        : [];

    var streams = nativeStreams
      .map(function(item) {
        if (!item || !item.url) return null;

        var headers = sanitizeNativePlaybackHeaders(
          item.headers,
          absolute
        );

        return {
          url: String(item.url),
          quality: inferQuality(
            item.url,
            item.label || label || PROVIDER_NAME
          ),
          referer: absolute,
          headers: headers,
          serverLabel:
            label ||
            item.label ||
            "WebView"
        };
      })
      .filter(Boolean)
      .sort(function(a, b) {
        var transport =
          nativeTransportScore(b.url) -
          nativeTransportScore(a.url);
        if (transport !== 0) return transport;

        return String(a.quality || "").localeCompare(
          String(b.quality || "")
        );
      });

    console.log(
      "[" + PROVIDER_NAME + "] native WebView streams=" + streams.length
    );

    return {
      streams: streams,
      subtitles: []
    };
  }).catch(function(error) {
    console.log(
      "[" + PROVIDER_NAME + "] native WebView failed host=" +
      hostOf(absolute) +
      " error=" +
      (error && error.message ? error.message : String(error))
    );
    return emptyResolved();
  });
}

function extractorNameFor(url) {
  var host = hostOf(url);

  if (hostMatches(host, STREAMWISH_DOMAINS)) return "StreamWish";
  if (hostMatches(host, VIDHIDE_DOMAINS)) return "VidHidePro";
  if (hostMatches(host, FILEMOON_DOMAINS) || host.indexOf("filemoon") !== -1) return "FileMoon";
  if (hostMatches(host, DOOD_DOMAINS) || host.indexOf("dood.") !== -1) return "Dood";
  if (hostMatches(host, MIXDROP_DOMAINS) || host.indexOf("mixdrop.") !== -1) return "MixDrop";
  if (hostMatches(host, STREAMTAPE_DOMAINS) || host.indexOf("streamtape.") !== -1) return "StreamTape";
  if (hostMatches(host, VIDMOLY_DOMAINS) || host.indexOf("vidmoly.") !== -1) return "Vidmoly";
  if (hostMatches(host, LULU_DOMAINS) || host.indexOf("luluvdo") !== -1 || host.indexOf("lulustream") !== -1) return "LuluStream";
  if (hostMatches(host, VOE_DOMAINS) || host === "voe.sx") return "Voe";
  if (
    host.indexOf("palankyurok.com") !== -1 ||
    host.indexOf("abyss") !== -1 ||
    host.indexOf("ezpla") !== -1 ||
    host.indexOf("seekp") !== -1 ||
    host.indexOf("p2pst") !== -1 ||
    host.indexOf("upns") !== -1
  ) return "BrowserPlayer";

  return "Generic";
}

function dispatchExtractor(url, referer, depth, allowWebView) {
  var name = extractorNameFor(url);
  console.log("[PencuriMovie] extractor=" + name + " host=" + hostOf(url));

  var work;
  if (name === "StreamWish") work = extractStreamWish(url, referer);
  else if (name === "VidHidePro") work = extractVidHide(url, referer);
  else if (name === "FileMoon") work = extractFileMoon(url, referer);
  else if (name === "Dood") work = extractDood(url);
  else if (name === "MixDrop") work = extractMixDrop(url);
  else if (name === "StreamTape") work = extractStreamTape(url);
  else if (name === "Vidmoly") work = extractVidmoly(url, referer);
  else if (name === "LuluStream") work = extractLulu(url, referer);
  else if (name === "Voe") work = extractVoe(url, referer);
  else if (name === "BrowserPlayer") work = allowWebView === false
    ? emptyResolved()
    : resolveWithNativeWebView(url, referer, "BrowserPlayer");
  else work = extractGenericHost(url, referer, depth || 0, allowWebView);

  return Promise.resolve(work).then(function(resolved) {
    var streams = resolved && Array.isArray(resolved.streams) ? resolved.streams.length : 0;
    console.log("[PencuriMovie] " + name + " streams=" + streams);

    /*
     * A recognised host can change its frontend. If the specific extraction
     * produced nothing, try the generic packed/JWPlayer parser before giving up.
     */
    if (streams) return resolved || emptyResolved();

    return extractGenericHost(url, referer, 1, allowWebView)
      .catch(function() {
        return resolved || emptyResolved();
      })
      .then(function(genericResolved) {
        var genericStreams =
          genericResolved && Array.isArray(genericResolved.streams)
            ? genericResolved.streams.length
            : 0;

        if (genericStreams) return genericResolved;

        if (allowWebView === false) {
          return genericResolved || resolved || emptyResolved();
        }

        return resolveWithNativeWebView(
          url,
          referer,
          name === "Generic" ? "WebView" : name
        );
      });
  });
}

function loadExtractorEquivalent(url, referer, depth, allowWebView) {
  var absolute = safeUrl(url, referer);
  if (!absolute) return Promise.resolve(emptyResolved());

  if (isDirectMedia(absolute)) {
    return Promise.resolve({
      streams: [{
        url: absolute,
        quality: inferQuality(absolute, ""),
        referer: referer || absolute,
        headers: referer ? { "Referer": referer } : {}
      }],
      subtitles: []
    });
  }

  var directName = extractorNameFor(absolute);
  if (directName === "BrowserPlayer") {
    if (allowWebView === false) {
      return Promise.resolve(
        emptyResolved()
      );
    }

    console.log("[PencuriMovie] native direct host=" + hostOf(absolute));
    return resolveWithNativeWebView(
      absolute,
      referer || absolute,
      "BrowserPlayer"
    );
  }

  return followRedirectCloudstream(absolute, referer).then(function(finalUrl) {
    finalUrl = finalUrl || absolute;
    console.log(
      "[PencuriMovie] iframe=" + hostOf(absolute) +
      (finalUrl !== absolute ? " redirect=" + hostOf(finalUrl) : "")
    );
    return dispatchExtractor(finalUrl, referer || absolute, depth || 0, allowWebView);
  });
}

function resolveMovieplayFrames(
  html,
  pageUrl
) {
  var direct =
    extractJwPlayerMedia(
      html,
      pageUrl
    );

  var resolved = {
    streams:
      direct.map(function(item) {
        return {
          url: item.url,
          quality: item.quality,
          referer: pageUrl,
          headers: {
            "Referer": pageUrl
          },
          serverLabel:
            "Page"
        };
      }),
    subtitles:
      extractSubtitles(
        html,
        pageUrl
      )
  };

  var frames =
    extractMovieplayIframes(
      html,
      pageUrl
    );

  var seen = {};
  frames =
    frames.filter(function(frame) {
      var value =
        String(frame || "").trim();

      if (
        !value ||
        seen[value]
      ) {
        return false;
      }

      seen[value] = true;
      return true;
    });

  if (!frames.length) {
    if (resolved.streams.length) {
      return Promise.resolve(
        resolved
      );
    }

    throw new Error(
      "PencuriMovie movieplay iframe not found"
    );
  }

  console.log(
    "[PencuriMovie] movieplay iframes=" +
    frames.length
  );

  /*
   * Every iframe is eligible. Standard HTTP extractors run first with bounded
   * concurrency so one dead host cannot block the remaining servers.
   */
  return collectValuesBounded(
    frames.map(function(frame) {
      return function() {
        return loadExtractorEquivalent(
          frame,
          pageUrl,
          0,
          false
        )
          .catch(function(error) {
            console.log(
              "[PencuriMovie] standard extractor failed host=" +
              hostOf(frame) +
              " error=" +
              (
                error &&
                error.message
                  ? error.message
                  : String(error)
              )
            );

            return emptyResolved();
          })
          .then(function(child) {
            (child.streams || [])
              .forEach(function(stream) {
                if (!stream.serverLabel) {
                  stream.serverLabel =
                    extractorNameFor(frame);
                }
              });

            return {
              frame: frame,
              resolved: child
            };
          });
      };
    }),
    3,
    9200
  ).then(function(results) {
    var failedFrames = [];

    results.forEach(function(entry) {
      if (!entry) return;

      var child =
        entry.resolved ||
        emptyResolved();

      mergeResolved(
        resolved,
        child
      );

      if (
        !child.streams ||
        !child.streams.length
      ) {
        failedFrames.push(
          entry.frame
        );
      }
    });

    /*
     * Jobs that did not start before the standard-lane deadline also remain
     * eligible for fallback.
     */
    var attempted = {};
    results.forEach(function(entry) {
      if (entry && entry.frame) {
        attempted[entry.frame] = true;
      }
    });

    frames.forEach(function(frame) {
      if (!attempted[frame]) {
        failedFrames.push(frame);
      }
    });

    var fallbackSeen = {};
    failedFrames =
      failedFrames.filter(function(frame) {
        if (
          !frame ||
          fallbackSeen[frame]
        ) {
          return false;
        }

        fallbackSeen[frame] = true;
        return true;
      });

    console.log(
      "[PencuriMovie] standard streams=" +
      resolved.streams.length +
      " fallback frames=" +
      failedFrames.length
    );

    if (
      !nativeWebViewAvailable() ||
      !failedFrames.length
    ) {
      return resolved;
    }

    /*
     * Native WebView is expensive. Only this fallback lane is capped.
     * Prioritise browser-only hosts first, then unknown generic players.
     */
    failedFrames.sort(function(a, b) {
      function score(url) {
        var name =
          extractorNameFor(url);

        if (name === "BrowserPlayer") {
          return 0;
        }

        if (name === "Generic") {
          return 1;
        }

        return 2;
      }

      return score(a) - score(b);
    });

    var webViewFrames =
      failedFrames.slice(0, 3);

    return collectResolvedBounded(
      webViewFrames.map(function(frame) {
        return function() {
          return loadExtractorEquivalent(
            frame,
            pageUrl,
            0,
            true
          ).then(function(child) {
            (child.streams || [])
              .forEach(function(stream) {
                if (!stream.serverLabel) {
                  stream.serverLabel =
                    extractorNameFor(frame);
                }
              });

            return child;
          }).catch(function() {
            return emptyResolved();
          });
        };
      }),
      2,
      6800
    ).then(function(webResolved) {
      mergeResolved(
        resolved,
        webResolved
      );

      return resolved;
    });
  });
}
function resolvePlaybackPage(pageUrl) {
  return requestText(pageUrl, {}, 1800).then(function(result) {
    updateBaseFromUrl(result.url);
    return resolveMovieplayFrames(result.text, result.url || pageUrl);
  });
}

function buildStreams(resolved, info, mediaType, season, episode) {
  var subtitles = resolved && Array.isArray(resolved.subtitles) ? resolved.subtitles : [];
  var sources = resolved && Array.isArray(resolved.streams) ? resolved.streams : [];
  var seen = {};

  var episodeLabel =
    mediaType === "tv"
      ? " S" + String(season || 1).padStart(2, "0") +
        "E" + String(episode || 1).padStart(2, "0")
      : "";

  return sources.map(function(source, index) {
    if (!source || !source.url || seen[source.url]) return null;
    seen[source.url] = true;

    var referer = source.referer || cachedBaseUrl || FALLBACK_BASE_URL;

    return {
      name:
        PROVIDER_NAME +
        (
          source.serverLabel
            ? " " + source.serverLabel
            : sources.length > 1
              ? " Server " + (index + 1)
              : ""
        ),
      title: (info.title || PROVIDER_NAME) + episodeLabel,
      url: source.url,
      quality: source.quality || inferQuality(source.url, ""),
      subtitles: subtitles,
      headers: Object.assign({
        "User-Agent": USER_AGENT,
        "Referer": referer
      }, source.headers || {})
    };
  }).filter(Boolean);
}

function getStreams(tmdbId, mediaType, season, episode) {
  var type = mediaType === "movie" ? "movie" : "tv";
  var requestedSeason = Number(season || 1);
  var requestedEpisode = Number(episode || 1);

  console.log(
    "[PencuriMovie] Request tmdbId=" + tmdbId +
    " type=" + type +
    (type === "tv" ? " S" + requestedSeason + "E" + requestedEpisode : "")
  );

  var info;
  var baseUrl;

  var work = Promise.all([
    getTmdbInfo(tmdbId, type),
    getBaseUrl()
  ])
    .then(function(values) {
      info = values[0];
      baseUrl = values[1];

      if (!info || !info.title) throw new Error("TMDB title is empty");

      return findBestTitle(baseUrl, info, type);
    })
    .then(function(match) {
      var detailPromise = match.__detailHtml
        ? Promise.resolve({
            text: match.__detailHtml,
            url: match.href
          })
        : requestText(
            match.href,
            { "Referer": trimSlash(cachedBaseUrl || baseUrl) + "/" },
            1400
          );

      return detailPromise.then(function(detail) {
        updateBaseFromUrl(detail.url || match.href);

        if (type === "movie") {
          return {
            targetUrl: detail.url || match.href,
            detailHtml: detail.text
          };
        }

        var selected = parseEpisodeTarget(
          detail.text,
          detail.url || match.href,
          requestedSeason,
          requestedEpisode
        );

        return {
          targetUrl: selected.href,
          detailHtml: null
        };
      });
    })
    .then(function(target) {
      if (target.detailHtml && type === "movie") {
        return resolveMovieplayFrames(target.detailHtml, target.targetUrl);
      }

      return resolvePlaybackPage(target.targetUrl);
    })
    .then(function(resolved) {
      var streams = buildStreams(
        resolved,
        info,
        type,
        type === "tv" ? requestedSeason : null,
        type === "tv" ? requestedEpisode : null
      );

      console.log("[PencuriMovie] Direct streams found=" + streams.length);
      return streams;
    });

  return withSoftTimeout(work, 19500, "PencuriMovie provider")
    .catch(function(error) {
      console.error(
        "[PencuriMovie] " +
        (error && error.message ? error.message : String(error))
      );
      return [];
    });
}

module.exports = {
  getStreams: getStreams
};
